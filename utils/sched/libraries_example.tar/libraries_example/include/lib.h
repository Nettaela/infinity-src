#ifndef _H_LIB_FOOBAR_
#define _H_LIB_FOOBAR_

/* prints foo */
void foo(void);

/* prints bar */
void bar(void);

#endif