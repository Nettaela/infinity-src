#include <stdio.h>

void foo() {
    puts("foo2");
}