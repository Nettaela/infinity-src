#include "lib.h"

int main(int argc, char* argv[], char** envp)
{
    foo();
    bar();
    return 0;
}