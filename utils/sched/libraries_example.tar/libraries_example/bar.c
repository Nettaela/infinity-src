#include <stdio.h>

void bar() {
    puts("bar");
}